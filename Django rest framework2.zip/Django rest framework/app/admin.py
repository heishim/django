from django.contrib import admin

from . models import Fichier

# Register your models here.

admin.site.register(Fichier)
