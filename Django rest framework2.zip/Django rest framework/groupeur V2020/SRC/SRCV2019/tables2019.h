#define TR_NAME 	    "arbredec.tab"
#define DX_NAME10       "diag10cr.tab"
#define CCAM_NAME	    "ccamcara.tab"
#define GHS_INFO        "ghsinfo.tab"
#define TAB_GESTCOMP    "gestcomp.tab"  /* Fichier d'index pour les gestes compl�mentaires */
#define REF_AUTO        "autorefs.tab"
#define GHM_INFO        "rghminfo.tab"
#define SRCDGACT_NAME   "srcdgact.tab"
#define INNOV_REFER     "innova.tab"
#define TABCOMBI_NAME   "tabcombi.tab"
#define CCAMDESC_NAME   "ccamdesc.tab"  /* tables d'existence des codes actes CCAM sur 10 caract�res*/
#define GHSMINOR_NAME   "ghsminor.tab"  /* tables des GHS minor�s*/

#define CODE_NAME       "codegeog.tab"
#define FICUM_NAME      "ficum.txt"

