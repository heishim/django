	char finess [9];
	char version[3];
	/*cd FG10c
    char numrss [7];*/
    char numrss [20];
    char numrum [10]; /*n� du RUM*/

	char naiss[8];
	char sexe;
	char unmed[4];
	
    char litded[2];
	char datent[8];/*65*/
	char modent;
	char prov;
	char datsor[8];
	char modsor;
	char dest;/*77*/
	char sej_24;
	char hosp30;
	char codpost[5];
	char pdsnaiss[4];
	
    /*CD FG10c*/
    char agegest[2];
    
    /*CD FG13*/
    char datedernregles[8];

    char nbseance[2];
	char fil1[4];
	char nbds[2];
	char nba[3];
	char diagp[6];
    char igs[3];
    char fil2[3];
	char diagr[6];

    char ccodage;
    char typemachine_radioth;
    char typedosimetrie;

    char numeroinno[15];/*innovation*/

	char conversionHPHC;
	char priseenchargeRAAC;
	char filler[10];

